package com.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dao.EmployeeDao;
import com.bank.pojo.Employee;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeDao employeedao;

	public Employee saveEmployee(Employee e) {

		return employeedao.save(e);
	}

	public void DeleteEmployee(Integer id) {

		employeedao.deleteById(id);
	}

	public List<Employee> getAll() {
		List<Employee> employees = employeedao.findAll();
		return employees;
	}

	public Optional<Employee> getbyid(Integer id) {

		return employeedao.findById(id);

	}

	public Employee updateEmployee(Employee e) {
		return employeedao.save(e);
	}

}
